// Button.js

export function createSettingsButton() {
  const btn = document.createElement('button');
  btn.className = 'btn btn-square shadow-md';
  btn.title = 'Settings';

  // Using a single-path SVG for a Settings/Cog icon that matches the style 
  // and complexity of the other icons in the wplace.live button stack.
  btn.innerHTML = `
    <svg xmlns="http://www.w3.org/2000/svg" height="24" viewBox="0 0 24 24" width="24" fill="currentColor">
      <path d="M19.43 12.98c.04-.32.07-.64.07-.98s-.03-.66-.07-.98l2.11-1.65c.19-.15.24-.42.12-.64l-2-3.46c-.12-.22-.39-.31-.61-.22l-2.49 1c-.52-.38-1.09-.69-1.7-.93L15 3.14c-.03-.21-.2-.35-.41-.35h-4c-.21 0-.38.14-.41.35L9.27 5.05c-.6.24-1.18.55-1.7.93l-2.49-1c-.22-.09-.49 0-.61.22l-2 3.46c-.13.22-.08.49.11.64l2.11 1.65c-.04.32-.07.65-.07.98s.03.66.07.98l-2.11 1.65c-.19.15-.24.42-.12.64l2 3.46c.12.22.39.31.61.22l2.49-1c.52.38 1.09.69 1.7.93l.36 1.81c.03.21.2.35.41.35h4c.21 0 .38-.14.41-.35l.36-1.81c.6-.24 1.18-.55 1.7-.93l2.49 1c.22.09.49 0 .61-.22l2-3.46c.12-.22.07-.49-.12-.64l-2.11-1.65zm-7.43 3.97c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/>
    </svg>
  `;

  // Open modal
  btn.addEventListener('click', () => {
    const modal = document.getElementById('settings_modal_window');
    if (modal) modal.showModal();
  });

  return btn;
}

export default createSettingsButton;
