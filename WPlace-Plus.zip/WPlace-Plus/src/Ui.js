// src/Ui.js

// Function to generate content for linked extensions
function createLinkedSectionHtml(linkedSettings) {
  if (!linkedSettings || linkedSettings.length === 0) {
    return `
      <p class="text-slate-500 text-sm mb-2">
        No compatible extensions linked yet.
      </p>
    `;
  }

  let html = '';
  linkedSettings.forEach(ext => {
    // Section Header (Dynamic Name)
    html += `
      <div class="flex items-center gap-2 mt-4 mb-3">
        <span class="text-indigo-600 text-lg">🔗</span>
        <h3 class="text-base font-semibold text-slate-800 tracking-tight">${ext.sectionName}</h3>
      </div>
    `;

    // Loop through settings provided by the linked extension
    ext.settings.forEach(setting => {
      // Assuming all linked settings are simple toggles for this example
      const settingId = `linked_${ext.id}_${setting.key}`;
      html += `
        <div class="bg-slate-50 rounded-xl p-4 border border-slate-100 mb-3">
          <div class="flex justify-between items-center">
            <div>
              <div class="text-base font-medium text-slate-800 flex items-center gap-2">
                ${setting.icon || '🛠️'} ${setting.name}
              </div>
              <p class="text-sm text-slate-500 ml-6 mt-1">${setting.description || 'Settings provided by a linked extension.'}</p>
            </div>
            <label class="inline-flex items-center cursor-pointer" for="${settingId}">
              <input id="${settingId}" type="checkbox" class="sr-only" />
              <span><span></span></span>
            </label>
          </div>
        </div>
      `;
    });
  });
  return html;
}

// Update the main function signature to accept linked settings
export function createSettingsUi(versionString, linkedSettings = []) {
  // CSS injection block has been removed entirely, now handled by build.js.

  const dialog = document.createElement("dialog");
  dialog.className = "modal"; 
  dialog.id = "settings_modal_window";
  
  // Generate HTML for the linked extension sections
  const linkedExtensionHtml = createLinkedSectionHtml(linkedSettings);

  dialog.innerHTML = `
    <div class="modal-box w-full h-full rounded-2xl shadow-xl p-0 bg-white border border-slate-100">

      <div class="flex items-center justify-between px-6 pt-4 pb-2 border-b border-slate-100"> 
        <h1 class="text-xl font-semibold text-slate-800 tracking-tight">Wplace Plus</h1>
        <form method="dialog">
          <button class="rounded-lg p-1 text-2xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors" aria-label="Close">×</button>
        </form>
      </div>
      
      <div class="flex-1 overflow-y-auto px-6 pt-2 pb-0 bg-white"> 
        <div class="flex gap-2 mb-5">
          <label>
            <input type="radio" name="main_tabs" class="hidden peer" checked>
            <span>⚙️ <span>Settings</span></span>
          </label>
          <label>
            <input type="radio" name="main_tabs" class="hidden peer">
            <span>🛠️ <span>Tools</span></span>
          </label>
        </div>

        <div class="main_tab_panel">
          <div class="flex gap-3 border-b border-slate-100 mb-5">
            <label>
              <input type="radio" name="settings_sub" class="hidden peer" checked>
              <span>🌐 Website</span>
            </label>
            <label>
              <input type="radio" name="settings_sub" class="hidden peer">
              <span>🧩 Extension</span>
            </label>
          </div>

          <div class="settings_sub_panel">
            <div class="flex items-center gap-2 mb-3">
              <span class="text-blue-600 text-lg">🌐</span>
              <h2 class="text-lg font-bold text-slate-800 tracking-tight">Website Settings</h2>
            </div>

            <div class="flex items-center gap-2 mt-4 mb-3">
              <span class="text-purple-600 text-lg">🗺️</span>
              <h3 class="text-base font-semibold text-slate-800 tracking-tight">Map Preferences</h3>
            </div>

            <div class="bg-slate-50 rounded-xl p-4 border border-slate-100 mb-3">
              <div class="flex justify-between items-center">
                <div>
                  <div class="text-base font-medium text-slate-800 flex items-center gap-2">
                    ⭐ Hide favorites
                  </div>
                  <p class="text-sm text-slate-500 ml-6 mt-1">Hide favorited locations from the map</p>
                </div>
                <label class="inline-flex items-center cursor-pointer" for="hide_favorites_switch">
                  <input id="hide_favorites_switch" type="checkbox" class="sr-only" />
                  <span><span></span></span>
                </label>
              </div>
            </div>
          </div>

          <div class="settings_sub_panel hidden">
            <div class="flex items-center gap-2 mb-3">
              <span class="text-green-500 text-lg">🧩</span>
              <h2 class="text-lg font-bold text-slate-800 tracking-tight">Extension Settings</h2>
            </div>
            ${linkedExtensionHtml}
          </div>
        </div>

        <div class="main_tab_panel hidden">
          <div class="flex items-center gap-2 mb-3">
            <span class="text-blue-600 text-lg">🛠️</span>
            <h2 class="text-lg font-bold text-slate-800 tracking-tight">Tools</h2>
          </div>
          <p class="text-slate-500 text-sm mb-2">
            Tools & utilities will appear here.
          </p>
        </div>
      </div>

      <div class="pt-3 pb-4 px-6 flex justify-between items-center text-slate-400 text-xs rounded-b-2xl">
        <span>Version: ${versionString || "v1.2.0"}</span>
      </div>

      <div class="modal-backdrop bg-black/40 absolute inset-0 rounded-2xl"></div>

    </div>
  `;

  // Tab logic (main tab: Settings/Tools)
  const tabButtons = dialog.querySelectorAll("input[name='main_tabs']");
  const tabPanels = dialog.querySelectorAll(".main_tab_panel");
  tabButtons.forEach((btn, i) => {
    btn.addEventListener("change", () => {
      tabPanels.forEach((p, j) => p.classList.toggle("hidden", i !== j));
    });
  });

  // Sub-tabs (Website/Extension)
  const subButtons = dialog.querySelectorAll("input[name='settings_sub']");
  const subPanels = dialog.querySelectorAll(".settings_sub_panel");
  subButtons.forEach((btn, i) => {
    btn.addEventListener("change", () => {
      subPanels.forEach((p, j) => p.classList.toggle("hidden", i !== j));
    });
  });

  return dialog;
}

export default createSettingsUi;
