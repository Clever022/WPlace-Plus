// ==UserScript==
// @name         Wplace +
// @version 1.44
// @description  A userscript that add quality of life improvements to the wplace website
// @match        https://wplace.live/*
// @run-at       document-idle
// @grant        none
// ==/UserScript==

