// main.js
import createSettingsButton from './Button.js';
import createSettingsUi from './Ui.js';

// --- CONFIGURATION ---
const TARGET_SELECTOR = ".flex.flex-col.items-center.gap-3";
let settingsModalInstance = null;
let linkedExtensionSettings = []; // Central store for linked settings

// --- EXTENSION LINKING REGISTRY ---

function initializeSettingsUi() {
    // Check if the modal instance is null or if the element has been removed from the DOM
    if (!settingsModalInstance || !document.body.contains(settingsModalInstance)) {
        // Pass the linked settings data to the UI generator
        const ui = createSettingsUi(GLOBAL_EXTENSION_VERSION || 'v0.0.0', linkedExtensionSettings); 
        document.body.appendChild(ui);
        settingsModalInstance = ui;
    }
}

// 1. Define the registration function
function registerExtensionSettings(extensionId, sectionName, settingsArray) {
    if (!extensionId || !sectionName || !Array.isArray(settingsArray)) {
        console.error("Invalid registration attempt. Missing ID, Name, or Settings array.");
        return;
    }

    // Check if this extension is already registered
    const existingIndex = linkedExtensionSettings.findIndex(ext => ext.id === extensionId);
    if (existingIndex !== -1) {
        linkedExtensionSettings[existingIndex] = { id: extensionId, sectionName, settings: settingsArray };
    } else {
        linkedExtensionSettings.push({ id: extensionId, sectionName, settings: settingsArray });
    }
    
    console.log(`WplacePlus: Registered settings for linked extension: ${sectionName}`);

    // Force re-initialization if the modal exists to display new settings
    if (settingsModalInstance) {
        settingsModalInstance.remove(); // Remove old element
        settingsModalInstance = null;
        initializeSettingsUi(); // Create and append new element
    } else {
        initializeSettingsUi(); // Ensure the UI initializes on first run
    }
}

// 2. Expose the registration function globally
if (typeof window.WPLACEPLUS_API === 'undefined') {
    window.WPLACEPLUS_API = {};
}
window.WPLACEPLUS_API.registerExtensionSettings = registerExtensionSettings;


// --- NOTIFICATION (unchanged) ---
const style = document.createElement("style");
style.textContent = `
  .wplace-notification {
    position: fixed;
    top: 20px;
    left: 50%;
    transform: translateX(-50%);
    background-color: #4CAF50;
    color: white;
    padding: 16px 24px;
    border-radius: 8px;
    font-size: 16px;
    font-weight: bold;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    z-index: 10000;
    opacity: 1;
    transition: opacity 1s ease-in-out;
  }
`;
document.head.appendChild(style);

const notification = document.createElement("div");
notification.className = "wplace-notification";
notification.textContent = "loaded";
document.body.appendChild(notification);

setTimeout(() => {
  notification.style.opacity = "0";
  setTimeout(() => notification.remove(), 1000);
}, 4000);


// Inject button into the menu
function injectButton(menu) {
  if (!menu) return;

  if (menu.querySelector('button[title="Settings"]')) return;

  const btn = createSettingsButton();
  // Add click listener to ensure UI is initialized/re-initialized and opened
  btn.addEventListener('click', () => {
      initializeSettingsUi();
      if (settingsModalInstance) {
          settingsModalInstance.showModal();
      }
  });
  
  menu.appendChild(btn);
}

function checkMenu() {
  const menu = document.querySelector(TARGET_SELECTOR);
  if (menu) {
    injectButton(menu);
  }
}

// --- INITIALIZATION ---

// Run once and watch for DOM changes
checkMenu();
initializeSettingsUi(); 

const observer = new MutationObserver(() => {
  checkMenu();
});

observer.observe(document.body, { childList: true, subtree: true });
