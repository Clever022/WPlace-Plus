// build.js

import fs from "fs";
import path from "path";
import { execSync } from "child_process";

// 1. Define the path to the header file
const HEADER_PATH = "src/wplaceplus.meta.js";
// 2. Define the path to the CSS file
const CSS_PATH = "src/Ui.css"; 

// --- Argument Handling Logic ---

const args = process.argv.slice(2);
const releaseType = args[0] ? args[0].toLowerCase() : null;
const shouldCopy = args.includes("copy");

let incrementValue;
let fixedDecimals;

if (releaseType === "beta") {
  incrementValue = 0.01;
  fixedDecimals = 2; 
  console.log("🛠️ Building BETA release: Version will increment by 0.01.");
} else {
  incrementValue = 0.1;
  fixedDecimals = 1; 
  console.log("🚀 Building STABLE release: Version will increment by 0.1.");
}

if (shouldCopy) {
  console.log("📋 Clipboard copy ENABLED");
}

// Read the files
let header = fs.readFileSync(HEADER_PATH, "utf8");
let main = fs.readFileSync("src/main.js", "utf8");
let cssContent = fs.readFileSync(CSS_PATH, "utf8");

// --- Version Increment Logic ---

const versionRegex = /@version\s+([0-9.]+)/;
const match = header.match(versionRegex);

let newVersion = "0.0.0"; 

if (match) {
  let currentVersion = parseFloat(match[1]);
  newVersion = (currentVersion + incrementValue).toFixed(fixedDecimals);

  console.log(`Updating version from ${currentVersion.toFixed(fixedDecimals)} to ${newVersion}`);

  header = header.replace(versionRegex, `@version ${newVersion}`);
  fs.writeFileSync(HEADER_PATH, header, "utf8");

  console.log("Updated version in " + HEADER_PATH);
} else {
  console.warn("Could not find @version tag in " + HEADER_PATH + ". Version was not incremented.");
}

// --- Inline Local Imports ---

function inlineLocalImports(code) {
  return code.replace(/import\s+([^;]+)\s+from\s+["']\.\/([^"']+)\.js["'];?/g, (match, imports, file) => {
    const filePath = path.join("src", `${file}.js`);
    if (!fs.existsSync(filePath)) return match;

    let content = fs.readFileSync(filePath, "utf8");

    content = content.replace(/export\s+default\s+[^;\n]+;?/g, "");
    content = content.replace(/export\s+(function|const|let|var|class)\s+/g, "$1 ");
    content = content.replace(/export\s*{[^}]+};?/g, "");

    return content;
  });
}

main = inlineLocalImports(main);

// --- CSS and JS Final Output Construction ---

const escapedCssContent = cssContent.replace(/`/g, "\\`");

const cssInjectionCode = `
// CSS Injection
if (!document.getElementById("settings-ui-css")) {
  const style = document.createElement("style");
  style.id = "settings-ui-css";
  style.textContent = \`${escapedCssContent}\`;
  document.head.appendChild(style);
}
`;

// Version Injection Code
const versionInjectionCode = `
// Inject Global Version for UI display
const GLOBAL_EXTENSION_VERSION = 'v${newVersion}';
`;

const output = `${header}
(function () {
  ${cssInjectionCode.split('\n').join('\n  ')}

  ${versionInjectionCode.split('\n').join('\n  ')} 

${main
  .split("\n")
  .map(l => "  " + l)
  .join("\n")}
})();
`;

// --- Write Build File ---

fs.mkdirSync("dist", { recursive: true });
fs.writeFileSync("dist/wplace.user.js", output, "utf8");

console.log("✅ Built dist/wplace.user.js");

// --- CLIPBOARD COPY LOGIC ---

if (shouldCopy) {
  try {
    if (process.platform === "win32") {
      execSync("clip").write?.(output);
    } else if (process.platform === "darwin") {
      execSync("pbcopy", { input: output });
    } else {
      execSync("xclip -selection clipboard", { input: output });
    }

    console.log("✅ Output copied to clipboard!");
  } catch (err) {
    console.error("❌ Clipboard copy failed. Make sure clipboard tools are installed.");
  }
}